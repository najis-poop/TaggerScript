# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['taggerscript']
install_requires = \
['lark>=1.1.5,<2.0.0']

setup_kwargs = {
    'name': 'taggerscript',
    'version': '0.0.1',
    'description': 'Scripting language written in Python for Discord bot',
    'long_description': '# Tagger\n\nTagger is a scripting language for Discord bot. It can be used from tag command to user automation moderation. It is simple but powerful. Users cannot run code that can harm your bot. You can add new function and class to it in a simple way.\n\n# Example\n\n```tagger\n{do\n    {msg.set("React with :heart: to claim this present")}\n    {msg.wait_for("reaction", ":heart:")}\n    {msg.set("Just kidding there is no present")}\n}\n```\nCheck example for more\n\n# Documentation\n\ncoming soon\n\n# Feedback\n\nTagger still in development. Any bug should be reported quickly by creating issue in github issue.',
    'author': 'najis',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
